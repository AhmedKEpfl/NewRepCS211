package game;

import processing.core.*;

public class TangibleGame extends PApplet{
	
	
	final static int WINDOW_WIDTH = 600, WINDOW_HEIGHT = 600;
	Mover mover;
	
	public void setup(){
		size(WINDOW_WIDTH, WINDOW_HEIGHT, P3D);
		mover = new Mover(this);
	}
	
	public void draw(){
		mover.update();
		mover.display();
	}
	
	public void mouseDragged() {
			mover.addRotationX((PI / 180) * (mouseY - pmouseY) * mover.getSpeed());
		    if (mover.getRotationX() > PI / 3) {
		      mover.setRotationX(PI / 3);
		    } else if (mover.getRotationX() < -PI / 3) {
		    	mover.setRotationX(-PI / 3);
		    }
		    
		    mover.addRotationZ((PI / 180) * (mouseX - pmouseX) * mover.getSpeed());
		    
		    if (mover.getRotationZ() > PI / 3) {
			  mover.setRotationZ(PI / 3);
	        } else if (mover.getRotationZ() < -PI / 3) {
	         	mover.setRotationZ(-PI / 3);
		    }
	  }
}
