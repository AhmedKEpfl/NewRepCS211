package game;

import java.util.ArrayList;
import java.util.List;

import processing.core.*;

public class Mover extends PApplet {
	
	private PVector location, velocity, acceleration, rotation, friction;
	PApplet app;
	
	int compteurSmileysHeureux;
	private float speed = 1;
	final static float normalForce = 1;
	final static float mu = 0.01f;
	final static float frictionMagnitude = normalForce * mu;
	final static float gravityConstant = 0.1f;
	final static int BLOCK_HEIGHT = 30;
	final static int SCALE_X = 20;
	final static int SCALE_Z = 20;
	
	List<PVector> listeEnnemis;
	
	PShape smileyMechant;
	
	public void setup(){
		size(TangibleGame.WINDOW_WIDTH, TangibleGame.WINDOW_HEIGHT, P3D);
	}
	
	public Mover(PApplet applet){
		location = new PVector(0 ,0, 0);
		velocity = new PVector(0, 0, 0);
		acceleration = new PVector(0, 0, 0);
		rotation = new PVector(0, 0, 0);
		app = applet;
		
		compteurSmileysHeureux = 0;
	    listeEnnemis = new ArrayList<PVector>();
	    //barChartColumns = new ArrayList<Integer>();
	    //listeSmileys = new Smiley[numberSmileys];
	    //smileysMechants = new ArrayList<Smiley>();
	    
	    //hs = new HScrollbar(positionScrollX, positionScrollY, 200, 15);
	    
	    smileyMechant = app.loadShape("C:/Users/Ahmed/Documents/GitHub/assignmentcs211/TGame/src/arbreSimpleFinal.obj");
	    smileyMechant.scale(25);
	    smileyMechant.rotateZ(PI);
	    
	    
	}
	
	public void update() {
	    friction = velocity.get();
	    friction.mult(-1);
	    friction.normalize();
	    friction.mult(frictionMagnitude);
	    /*if (compteur > COUNTER_BAR_CHART) {
	      barChartColumns.add((int)score);
	      compteur = -1;
	    }
	    compteur++;*/
	    acceleration.x = sin(rotation.z) * gravityConstant;
	    acceleration.z = -sin(rotation.x) * gravityConstant;

	    acceleration.add(friction);

	    velocity.add(acceleration);

	    location.add(velocity);
	    //rectBarChartWidth = RECT_BAR_CHART_WIDTH_INITIAL * hs.getPos();
	  }
	
	public void display() {
	    app.lights();
	    app.pushMatrix();

	    app.stroke(50, 50, 50);
	    app.fill(50, 50, 50);
	    app.background(200, 200, 200);
	    app.text("rotationX: " + degrees(rotation.x) + 
	      "  RotationZ: " + degrees(rotation.z) + 
	      "  Speed: " + speed, 10, 10);
	    app.translate(TangibleGame.WINDOW_WIDTH / 2, TangibleGame.WINDOW_HEIGHT / 2 + BLOCK_HEIGHT);
	    app.scale(0.6f);

	    //Smileys:
	    /*for(int i = 0; i < numberSmileys; i++){
	      pushMatrix();
	      translate(listeSmileys[i].getX(), listeSmileys[i].getY(), listeSmileys[i].getZ());
	      scale(listeSmileys[i].getScale());
	      listeSmileys[i].lookAt(location.x, location.y, location.z);
	      rotateY(listeSmileys[i].getRotationY());
	      rotateX(listeSmileys[i].getRotationX());
	      if(listeSmileys[i].getHeureux()){
	        shape(smileyHeureux);
	      } else {
	        shape(smileyTriste);
	      }
	      popMatrix();
	    }*/
	    app.rotateX(rotation.x - PI / 5);
	    app.rotateY(rotation.y);
	    app.rotateZ(rotation.z);
	    app.pushMatrix();
	    app.scale(SCALE_X, 1, SCALE_Z);
	    app.box(BLOCK_HEIGHT);
	    app.popMatrix();
	    for (int i = 0; i < listeEnnemis.size (); i++) {
	      addEnnemi(listeEnnemis.get(i));
	    }

	    app.translate(location.x, -BLOCK_HEIGHT, location.z);
	    app.stroke(100, 100, 100);
	    app.fill(200, 200, 200);
	    app.sphere(BLOCK_HEIGHT / 2.0f);
	    app.popMatrix();
	    /*app.drawDataVisualization();
	    image(dataVisualization, 0, height - dataVisualization.height);
	    hs.update();
	    hs.display();*/
	    
	}
	
	public void setRotationX(float newValue){
		rotation.x = newValue;
	}
	
	public void setRotationZ(float newValue){
		rotation.z = newValue;
	}
	
	public void addRotationX(float addValue){
		rotation.x += addValue;
	}
	
	public void addRotationZ(float addValue){
		rotation.z += addValue;
	}
	
	public float getRotationX(){
		return rotation.x;
	}
	
	public float getRotationZ(){
		return rotation.z;
	}
	
	public float getSpeed(){
		return speed;
	}
	
	public void addEnnemi(PVector ennemi){
		app.pushMatrix();
		app.translate(0, 0, -BLOCK_HEIGHT);
		app.shape(smileyMechant);
		app.popMatrix();
	}
}
